1. How to compile this project
	$ make

2. Execute testParser and test it with "test.c, test2.c and test3.c". 
	$ make test

3. Delete all files produced automatically
	$ make clear

4. Delete files and compile and test again
	$ make run 
