void main()
{
		int a;
		float b;

		a = b+1;
		b = a + 2 - 3 * 4 + 5;

		do{
			a=b*10+2;
		}while(a<1000);


		for(int i=0;i<100;i=i+1)
		{
			for(int k=0;k<200;k=k+1)
			{
				for(int g=0;g<300;g--)
				{
					a=a+b*12;
				}
			}
		}
}
